import './styles/style.css';

import { runApp } from './runApp';

runApp(document.getElementById('app'));
